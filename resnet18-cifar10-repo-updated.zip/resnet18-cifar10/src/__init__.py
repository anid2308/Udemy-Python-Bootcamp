"""ResNet-18 on CIFAR-10 utilities."""
